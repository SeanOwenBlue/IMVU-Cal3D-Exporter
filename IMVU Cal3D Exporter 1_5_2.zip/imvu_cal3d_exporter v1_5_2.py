# ##### BEGIN GPL LICENSE BLOCK #####
#
# This file is part of the Blender 4.43+ to Cal3d exporter targeted
# primarily for IMVU compatibility.
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


bl_info = {
    "name": "IMVU Cal3D Export",
    "author":   "Jean-Baptiste Lamy (Jiba), " \
                "Chris Montijin, "            \
                "Damien McGinnes, "           \
                "David Young, "               \
                "Alexey Dorokhov, "           \
                "Matthias Ferch, "            \
                "Peter Amstutz, "             \
                "Etory, "                     \
                "Jacob Boerema, "             \
                "Sean Owen Blue",       
    "version": (1, 5, 2),
    "blender": (4, 4, 3),
    "location": "File > Export",
    "description": "Exports XSF, XAF, XPF, XMF, and XRF for IMVU",
    "category": "Import-Export",
}

import bpy
from bpy_extras.io_utils import ExportHelper
from mathutils import Quaternion, Vector, Matrix
from collections import defaultdict
from bpy_extras import anim_utils
import os
import shutil
import re

# -----------------------------
# Helper Functions
# -----------------------------

# XML Version
xml_version=919

def quaternion_flip_continuity(quats):
    if not quats:
        return quats
    result = [quats[0]]
    for q in quats[1:]:
        if result[-1].dot(q) < 0.0:
            q = -q
        result.append(q)
    return result

def get_bone_id_map(armature_obj):
    bone_id_map = {}
    if armature_obj and armature_obj.type == 'ARMATURE':
        for i, bone in enumerate(armature_obj.data.bones):
            bone_id_map[bone.name] = i
    return bone_id_map

def get_texture_from_material(mat):
    if mat.use_nodes:
        for node in mat.node_tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image:
                return node.image
    return None

def write_dummy_xsf(filepath, mesh_name):
    content = f'''<HEADER MAGIC="XSF" VERSION="{xml_version}" />
<SKELETON NUMBONES="2" SCENEAMBIENTCOLOR="0 0 0">
    <BONE NAME="RootNode" ID="0">
        <TRANSLATION>0 0 0</TRANSLATION>
        <ROTATION>0 0 0 -1</ROTATION>
        <LOCALTRANSLATION>0 0 0</LOCALTRANSLATION>
        <LOCALROTATION>0 0 0 -1</LOCALROTATION>
        <PARENTID>-1</PARENTID>
        <CHILDID>1</CHILDID>
    </BONE>
    <BONE NAME="{mesh_name}" ID="1">
        <TRANSLATION>0 0 0</TRANSLATION>
        <ROTATION>0 0 0 -1</ROTATION>
        <LOCALTRANSLATION>0 0 0</LOCALTRANSLATION>
        <LOCALROTATION>0 0 0 -1</LOCALROTATION>
        <PARENTID>0</PARENTID>
    </BONE>
</SKELETON>'''
    with open(filepath, 'w') as f:
        f.write(content)


# -----------------------------
# XSF Export
# -----------------------------
def export_xsf(armature_obj, filepath, write_ambient_color, scale=1.0):
    bones = armature_obj.data.bones
    lines = [f'<HEADER MAGIC="XSF" VERSION="{xml_version}"/>']

    ambient_r, ambient_g, ambient_b = (0.525176, 0.555059, 0.545235)
    if not write_ambient_color:
        ambient_r, ambient_g, ambient_b = (0.0, 0.0, 0.0)

    lines.append(f'<SKELETON NUMBONES="{len(bones)}" SCENEAMBIENTCOLOR="{ambient_r:.6f} {ambient_g:.6f} {ambient_b:.6f}">')

    processed_bones = {}
    bone_id_counter = 0

    def process_bone_recursive(b, parent_info=None):
        nonlocal bone_id_counter
        name = b.name
        
        if parent_info is None:
            # Root Bone: Scale world position
            loc = (armature_obj.matrix_world @ b.matrix_local).to_translation() * scale
            quat = b.matrix_local.to_quaternion()
        else:
            parent_bone = parent_info['bone']
            # Child Bone: Scale distance from parent
            loc_diff = (b.matrix_local.to_translation() - parent_bone.matrix_local.to_translation()) * scale
            parent_rot_mat = parent_bone.matrix_local.to_quaternion().to_matrix()
            loc = loc_diff @ parent_rot_mat
            quat = (parent_bone.matrix_local.inverted() @ b.matrix_local).to_quaternion()

        m = quat.to_matrix().to_4x4()
        m.translation = loc
        if parent_info:
            m = parent_info['matrix'] @ m
        
        lmatrix = m.inverted()
        lloc = lmatrix.to_translation()
        lquat = lmatrix.to_quaternion()

        # LIGHTS
        is_light, light_type, light_color = False, 0, [0.5, 0.5, 0.5]
        testname = name.lower()
        if testname.startswith("omni"):
            is_light, light_type = True, 1
        elif testname.startswith("spot"):
            is_light, light_type = True, 3
        
        if is_light and name in bpy.data.lights:
            light_color = list(bpy.data.lights[name].color)

        current_id = bone_id_counter
        bone_id_counter += 1
        
        processed_bones[name] = {
            'id': current_id,
            'parent_id': parent_info['id'] if parent_info else -1,
            'loc': loc,
            'quat': quat,
            'lloc': lloc,
            'lquat': lquat,
            'is_light': is_light,
            'light_type': light_type,
            'light_color': light_color,
            'child_ids': []
        }

        current_info = {'bone': b, 'matrix': m, 'id': current_id}
        for child in b.children:
            if child.name in bones:
                c_id = process_bone_recursive(child, current_info)
                processed_bones[name]['child_ids'].append(c_id)
        
        return current_id

    for bone in bones:
        if not bone.parent:
            process_bone_recursive(bone)

    for name, data in processed_bones.items():
        q_inv = data['quat'].inverted()
        lq_inv = data['lquat'].inverted()

        bone_line = f'  <BONE NAME="{name}" NUMCHILDS="{len(data["child_ids"])}" ID="{data["id"]}"'
        if data['is_light']:
            c = data['light_color']
            bone_line += f' LIGHTTYPE="{data["light_type"]}" LIGHTCOLOR="{c[0]:.6f} {c[1]:.6f} {c[2]:.6f}">'
        else:
            bone_line += ">"
        
        lines.append(bone_line)
        lines.append(f'    <TRANSLATION>{data["loc"].x:.6f} {data["loc"].y:.6f} {data["loc"].z:.6f}</TRANSLATION>')
        lines.append(f'    <ROTATION>{-q_inv.x:.6f} {-q_inv.y:.6f} {-q_inv.z:.6f} {-q_inv.w:.6f}</ROTATION>')
        lines.append(f'    <LOCALTRANSLATION>{data["lloc"].x:.6f} {data["lloc"].y:.6f} {data["lloc"].z:.6f}</LOCALTRANSLATION>')
        lines.append(f'    <LOCALROTATION>{-lq_inv.x:.6f} {-lq_inv.y:.6f} {-lq_inv.z:.6f} {-lq_inv.w:.6f}</LOCALROTATION>')
        lines.append(f'    <PARENTID>{data["parent_id"]}</PARENTID>')
        for c_id in data['child_ids']:
            lines.append(f'    <CHILDID>{c_id}</CHILDID>')
        lines.append('  </BONE>')

    lines.append('</SKELETON>')
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

# -----------------------------
# XAF Export
# -----------------------------
def export_xaf(armature_obj, filepath, scale=1.0, keyframe_all=False):
    obj = armature_obj
    anim_data = obj.animation_data
    if not anim_data or not anim_data.action:
        return

    action = anim_data.action
    slot = anim_data.action_slot

    channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
    if not channelbag:
        return

    fps = bpy.context.scene.render.fps
    start_frame, end_frame = bpy.context.scene.frame_start, bpy.context.scene.frame_end
    duration = (end_frame - start_frame) / fps

    bones = obj.data.bones
    
    # Pre-calculate rest data for all bones
    bone_rest_data = {}
    for b in bones:
        if not b.parent:
            loc = (obj.matrix_world @ b.matrix_local).to_translation() * scale
            quat = b.matrix_local.to_quaternion()
        else:
            loc_diff = (b.matrix_local.to_translation() - b.parent.matrix_local.to_translation()) * scale
            parent_rot_mat = b.parent.matrix_local.to_quaternion().to_matrix()
            loc = loc_diff @ parent_rot_mat
            quat = (b.parent.matrix_local.inverted() @ b.matrix_local).to_quaternion()
        bone_rest_data[b.name] = {'loc': loc, 'quat': quat}

    # Map F-Curves to bones and track which bones have data
    bone_fcurves = defaultdict(lambda: {'loc': [None]*3, 'rot': [None]*4})
    active_bone_names = set()

    for fc in channelbag.fcurves:
        for bname in bone_rest_data:
            if f'["{bname}"]' in fc.data_path:
                active_bone_names.add(bname)
                if "location" in fc.data_path: 
                    bone_fcurves[bname]['loc'][fc.array_index] = fc
                elif "rotation_quaternion" in fc.data_path: 
                    bone_fcurves[bname]['rot'][fc.array_index] = fc

    # Filter which bones to actually write to the file
    if keyframe_all:
        bones_to_export = list(bones)
    else:
        bones_to_export = [b for b in bones if b.name in active_bone_names]

    lines = [f'<HEADER MAGIC="XAF" VERSION="{xml_version}"/>']
    lines.append(f'<ANIMATION DURATION="{duration:.5f}" NUMTRACKS="{len(bones_to_export)}">')

    # Important: We need the full list to keep BONEID consistent with the XSF file
    full_bone_list = list(bones)

    for b in bones_to_export:
        bidx = full_bone_list.index(b)
        rest = bone_rest_data[b.name]
        curves = bone_fcurves[b.name]
        
        all_curves = [c for c in curves['loc'] + curves['rot'] if c is not None]
        frames = set()
        for fc in all_curves:
            for kp in fc.keyframe_points:
                if start_frame <= kp.co.x <= end_frame: 
                    frames.add(int(round(kp.co.x)))
        
        # If no keyframes exist but we are exporting anyway, use the start frame
        sorted_frames = sorted(list(frames)) if frames else [int(start_frame)]

        lines.append(f'  <TRACK BONEID="{bidx}" NUMKEYFRAMES="{len(sorted_frames)}">')

        for f in sorted_frames:
            time = (f - start_frame) / fps
            
            # Evaluate Location
            dloc = Vector((0.0, 0.0, 0.0))
            for i in range(3):
                if curves['loc'][i]: dloc[i] = curves['loc'][i].evaluate(f)
            
            # Evaluate Rotation
            dquat = Quaternion((1.0, 0.0, 0.0, 0.0))
            if curves['rot'][0]: dquat.w = curves['rot'][0].evaluate(f)
            if curves['rot'][1]: dquat.x = curves['rot'][1].evaluate(f)
            if curves['rot'][2]: dquat.y = curves['rot'][2].evaluate(f)
            if curves['rot'][3]: dquat.z = curves['rot'][3].evaluate(f)

            # ROTATION: Combine delta with rest pose
            final_quat = dquat.copy()
            final_quat.rotate(rest['quat'])
            final_quat.normalize()

            # TRANSLATION: Combine delta with rest pose
            dloc_scaled = dloc * scale
            dloc_scaled.rotate(rest['quat'])
            final_loc = rest['loc'] + dloc_scaled

            lines.append(f'    <KEYFRAME TIME="{time:.5f}">')
            lines.append(f'      <TRANSLATION>{final_loc.x:.6f} {final_loc.y:.6f} {final_loc.z:.6f}</TRANSLATION>')
            lines.append(f'      <ROTATION>{final_quat.x:.6f} {final_quat.y:.6f} {final_quat.z:.6f} {-final_quat.w:.6f}</ROTATION>')
            lines.append(f'    </KEYFRAME>')
        lines.append('  </TRACK>')

    lines.append('</ANIMATION>')
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

# -----------------------------
# XPF Export
# -----------------------------
def export_xpf(selected_objects, filepath):
    scene = bpy.context.scene
    fps = scene.render.fps
    start, end = scene.frame_start, scene.frame_end

    merged_tracks = defaultdict(lambda: {})
    for obj in selected_objects:
        if not obj.data or not hasattr(obj.data, "shape_keys"):
            continue
        sk = obj.data.shape_keys
        if not sk or not sk.animation_data or not sk.animation_data.action:
            continue
        action = sk.animation_data.action
        slot = sk.animation_data.action_slot
        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
        if channelbag:
            for fcurve in channelbag.fcurves:
                if not fcurve.data_path.startswith("key_blocks"): continue
                name = fcurve.data_path.split('["')[1].split('"]')[0]
                for kp in fcurve.keyframe_points:
                    frame = int(round(kp.co.x))
                    if frame < start or frame > end: continue
                    value = fcurve.evaluate(frame)
                    merged_tracks[name][frame] = max(merged_tracks[name].get(frame,0.0), value)

    merged_tracks = {k:v for k,v in merged_tracks.items() if v}
    duration = (end - start)/fps

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(f'<HEADER MAGIC="XPF" VERSION="{xml_version}"/>\n')
        f.write(f'<ANIMATION NUMTRACKS="{len(merged_tracks)}" DURATION="{duration:.5f}">\n')
        for morph, frames in merged_tracks.items():
            ordered = sorted(frames.items())
            f.write(f'  <TRACK NUMKEYFRAMES="{len(ordered)}" MORPHNAME="{morph}">\n')
            for frame, value in ordered:
                t = (frame-start)/fps
                f.write(f'    <KEYFRAME TIME="{t:.5f}">\n')
                f.write(f'      <WEIGHT>{value:.6f}</WEIGHT>\n')
                f.write(f'    </KEYFRAME>\n')
            f.write('  </TRACK>\n')
        f.write('</ANIMATION>\n')

# -----------------------------
# XMF/XRF Export
# -----------------------------
def export_xrf(mat, export_path, prefix="", copy_textures=True):
    # Dictionary to store found maps
    found_maps = {}
    
    # NO MATERIAL
    if mat is None:
        xml_lines = [
            f'<HEADER MAGIC="XRF" VERSION="{xml_version}"/>',
            '  <MATERIAL NUMMAPS="1">',
            '    <AMBIENT>255 255 255 255</AMBIENT>',
            '    <DIFFUSE>255 255 255 255</DIFFUSE>',
            '    <SPECULAR>0 0 0 255</SPECULAR>',
            '    <SHININESS>0.000000</SHININESS>',
            '    <MAP TYPE="Diffuse Color">unused</MAP>',
            '  </MATERIAL>'
        ]
        xrf_filename = f"{prefix}_unused.xrf"
        with open(os.path.join(export_path, xrf_filename), "w", encoding='utf-8') as f:
            f.write("\n".join(xml_lines))
        return xrf_filename

    # REAL MATERIAL
    if mat.use_nodes:
        nodes = mat.node_tree.nodes
        bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
        
        if bsdf:
            def get_image_for_input(input_name):
                socket = bsdf.inputs.get(input_name)
                if not socket or not socket.is_linked:
                    return None
                link = socket.links[0]
                curr_node = link.from_node
                while curr_node:
                    if curr_node.type == 'TEX_IMAGE' and curr_node.image:
                        return curr_node.image
                    if curr_node.type == 'NORMAL_MAP':
                        inner_socket = curr_node.inputs.get("Color")
                        if inner_socket and inner_socket.is_linked:
                            curr_node = inner_socket.links[0].from_node
                            continue
                    break
                return None

            mapping_config = {
                "Base Color": "Diffuse Color",
                "Alpha": "Opacity",
                "Normal": "Normal",
                "Emission Color": "Emission",
                "Specular IOR Level": "Specular"
            }

            for blender_input, map_type in mapping_config.items():
                img = get_image_for_input(blender_input)
                if img:
                    tex_name = bpy.path.basename(img.filepath)
                    src_path = bpy.path.abspath(img.filepath)
                    if copy_textures and os.path.exists(src_path):
                        dst_path = os.path.join(export_path, tex_name)
                        if not os.path.exists(dst_path):
                            shutil.copy(src_path, dst_path)
                    found_maps[map_type] = tex_name

    num_maps = len(found_maps)
    if num_maps == 0:
        num_maps = 1
        found_maps["Diffuse Color"] = "unused"

    xml_lines = [
        f'<HEADER MAGIC="XRF" VERSION="{xml_version}"/>',
        f'  <MATERIAL NUMMAPS="{num_maps}">',
        '    <AMBIENT>255 255 255 255</AMBIENT>',
        '    <DIFFUSE>255 255 255 255</DIFFUSE>',
        '    <SPECULAR>0 0 0 255</SPECULAR>',
        '    <SHININESS>0.000000</SHININESS>'
    ]

    for m_type, m_file in found_maps.items():
        xml_lines.append(f'    <MAP TYPE="{m_type}">{m_file}</MAP>')

    xml_lines.append('  </MATERIAL>')

    safe_name = bpy.path.clean_name(mat.name)
    xrf_filename = f"{prefix}_{safe_name}.xrf" if prefix else f"{safe_name}.xrf"
    
    with open(os.path.join(export_path, xrf_filename), "w", encoding='utf-8') as f:
        f.write("\n".join(xml_lines))

    return xrf_filename


def export_xmf(obj, filepath, scale=1.0, export_xrf_flag=True, prefix="", copy_textures=True, exported_mats=None, compress=False):
    if obj.type != 'MESH':
        return print("Error: Select a Mesh.")

    # Determine float formatting precision based on compression checkbox status
    fmt = ".3f" if compress else ".6f"
    uv_round = 3 if compress else 6
    col_round = 3 if compress else 4

    export_folder = os.path.dirname(filepath)
    armature_obj = next((m.object for m in obj.modifiers if m.type == 'ARMATURE'), None)
    
    if armature_obj:
        bone_id_map = get_bone_id_map(armature_obj)
    else:
        bone_id_map = {"RootNode": 0, obj.name: 1}

    mesh_data = obj.data
    mesh_data.calc_loop_triangles()
    
    world_mat = obj.matrix_world
    norm_mat = world_mat.to_quaternion().to_matrix()

    xmf_xml = f'<HEADER MAGIC="XMF" VERSION="{xml_version}"/>\n'
    slots = obj.material_slots if len(obj.material_slots) > 0 else [None]
    xmf_xml += f'<MESH NUMSUBMESH="{len(slots)}">\n'

    for mat_idx, slot in enumerate(slots):
        vertices = []
        faces = []
        vert_lookup = {}

        if slot is None:
            triangles = mesh_data.loop_triangles
            material_id = "0"
            mat_to_export = None
        else:
            triangles = [t for t in mesh_data.loop_triangles if t.material_index == mat_idx]
            mat_to_export = slot.material
            material_id = str(mat_idx)
            match = re.search(r'\[(\d+)\]', slot.name)
            if match:
                material_id = match.group(1)

        color_layer = mesh_data.color_attributes.active_color or (mesh_data.color_attributes[0] if mesh_data.color_attributes else None)

        for tri in triangles:  
            face_indices = []  
            for loop_idx in tri.loops:  
                loop = mesh_data.loops[loop_idx]  
                v_idx = loop.vertex_index  
                v = mesh_data.vertices[v_idx]

                v_color = (1.0, 1.0, 1.0)  
                if color_layer:  
                    color_index = v_idx if color_layer.domain == 'POINT' else loop_idx  
                    if color_index < len(color_layer.data):  
                        v_color = color_layer.data[color_index].color[:3]

                uv = (0.0, 0.0)
                if mesh_data.uv_layers.active:
                    uv = mesh_data.uv_layers.active.data[loop_idx].uv

                v_key = (v_idx, round(uv[0], uv_round), round(uv[1], uv_round),
                         round(v_color[0], col_round), round(v_color[1], col_round), round(v_color[2], col_round))
                
                if v_key not in vert_lookup:
                    new_id = len(vertices)
                    vert_lookup[v_key] = new_id
                    
                    pos = world_mat @ v.co
                    norm = (norm_mat @ v.normal).normalized()

                    infs = []
                    if armature_obj:
                        for g in v.groups:
                            if g.group < len(obj.vertex_groups):
                                group_name = obj.vertex_groups[g.group].name
                                if group_name in bone_id_map and g.weight > 0.0001:
                                    infs.append([bone_id_map[group_name], g.weight])
                        
                        total_w = sum(inf[1] for inf in infs)
                        if total_w > 0:
                            for inf in infs:
                                inf[1] /= total_w
                        else:
                            infs = [[0, 1.0]]

                        infs.sort(key=lambda x: x[1], reverse=True)
                    else:
                        infs = [[1, 1.0]]
                    
                    vertices.append({
                        'id': new_id, 
                        'orig_idx': v_idx, 
                        'pos': pos, 
                        'norm': norm, 
                        'uv': uv, 
                        'color': v_color, 
                        'infs': infs
                    })
                
                face_indices.append(vert_lookup[v_key])
            faces.append(face_indices)

        morph_xml = ""
        num_morphs = 0
        if obj.data.shape_keys:
            basis = obj.data.shape_keys.reference_key
            for skey in obj.data.shape_keys.key_blocks:
                if skey == basis: continue
                blend_verts = []
                for v_info in vertices:
                    t_co = skey.data[v_info['orig_idx']].co
                    b_co = basis.data[v_info['orig_idx']].co
                    
                    diff = t_co - b_co
                    if diff.length > 0.00001:
                        target_world = world_mat @ t_co
                        u, v_coord = v_info['uv'][0], 1.0 - v_info['uv'][1]
                        
                        # --- Updated Morphs Float Precision formatting ---
                        bv = f'      <BLENDVERTEX VERTEXID="{v_info["id"]}" POSDIFF="{diff.length*scale:{fmt}}">\n'
                        bv += f'        <POSITION>{target_world.x*scale:{fmt}} {target_world.y*scale:{fmt}} {target_world.z*scale:{fmt}}</POSITION>\n'
                        bv += f'        <NORMAL>{v_info["norm"].x:{fmt}} {v_info["norm"].y:{fmt}} {v_info["norm"].z:{fmt}}</NORMAL>\n'
                        bv += f'        <TEXCOORD>{u:{fmt}} {v_coord:{fmt}}</TEXCOORD>\n'
                        bv += '      </BLENDVERTEX>\n'
                        blend_verts.append(bv)
                
                if blend_verts:
                    morph_xml += f'    <MORPH NAME="{skey.name}" NUMBLENDVERTS="{len(blend_verts)}" MORPHID="{num_morphs}">\n'
                    morph_xml += "".join(blend_verts)
                    morph_xml += '    </MORPH>\n'
                    num_morphs += 1

        xmf_xml += (f'  <SUBMESH NUMVERTICES="{len(vertices)}" NUMFACES="{len(faces)}" '
                    f'NUMLODSTEPS="0" NUMSPRINGS="0" NUMMORPHS="{num_morphs}" '
                    f'NUMTEXCOORDS="1" MATERIAL="{material_id}">\n')

        for v in vertices:
            # --- Updated Vertex Float Precision formatting ---
            xmf_xml += f'    <VERTEX NUMINFLUENCES="{len(v["infs"])}" ID="{v["id"]}">\n'
            xmf_xml += f'      <POS>{v["pos"].x*scale:{fmt}} {v["pos"].y*scale:{fmt}} {v["pos"].z*scale:{fmt}}</POS>\n'
            xmf_xml += f'      <NORM>{v["norm"].x:{fmt}} {v["norm"].y:{fmt}} {v["norm"].z:{fmt}}</NORM>\n'
            c = v["color"]
            xmf_xml += f'      <COLOR>{c[0]:{fmt}} {c[1]:{fmt}} {c[2]:{fmt}}</COLOR>\n'
            xmf_xml += f'      <TEXCOORD>{v["uv"][0]:{fmt}} {1.0 - v["uv"][1]:{fmt}}</TEXCOORD>\n'
            for b_id, weight in v["infs"]:
                xmf_xml += f'      <INFLUENCE ID="{b_id}">{weight:{fmt}}</INFLUENCE>\n'
            xmf_xml += '    </VERTEX>\n'

        xmf_xml += morph_xml
        for f in faces:
            xmf_xml += f'    <FACE VERTEXID="{" ".join(map(str, f))}"/>\n'
        xmf_xml += '  </SUBMESH>\n'

        if export_xrf_flag:
            export_xrf(mat_to_export, export_folder, prefix=prefix, copy_textures=copy_textures)

    xmf_xml += '</MESH>\n'
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(xmf_xml)


# -----------------------------
# Operator / UI
# -----------------------------
class EXPORT_OT_imvu_all(bpy.types.Operator, ExportHelper):
    """Export scene data to IMVU Cal3D format (.xsf, .xmf, .xrf, .xaf, .xpf)"""
    bl_idname = "export_scene.imvu_all"
    bl_label = "Export IMVU Cal3D"
    bl_options = {'REGISTER'}
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filename_ext = ""

    filter_glob: bpy.props.StringProperty(
        default="*.xaf;*.xpf;*.xsf;*.xmf;*.xrf",
        options={'HIDDEN'}
    )

    export_xsf: bpy.props.BoolProperty(
        name="Export XSF",
        description="Export the selected armature as XSF for IMVU",
        default=True)

    export_xaf: bpy.props.BoolProperty(
        name="Export XAF",
        description="Export the selected armature's current action as XAF for IMVU",
        default=True)

    export_xpf: bpy.props.BoolProperty(
        name="Export XPF",
        description="Export the selected objects' shapekey action as XPF for IMVU",
        default=True)

    export_xmf: bpy.props.BoolProperty(
        name="Export XMF",
        description="Export selected mesh as XMF for IMVU",
        default=True
    )

    compress_xmf: bpy.props.BoolProperty(
        name="Compress XMF Mesh",
        description="Reduces output resolution to 3 decimal places to compress file footprint size",
        default=False
    )


    export_xrf: bpy.props.BoolProperty(
        name="Export XRF",
        description="Export materials as XRF for IMVU",
        default=True
    )

    copy_textures: bpy.props.BoolProperty(
        name="Copy Textures",
        description="Copy image textures",
        default=False
    )

    keyframe_all: bpy.props.BoolProperty(
        name="Keyframe All Bones",
        description="If disabled, only bones with actual keyframes will be exported. If enabled, all bones will be exported",
        default=False
    )

    merge_xpf: bpy.props.BoolProperty(
        name="Merge XPF Files",
        description="Merge all selected shapekey animations into one XPF file",
        default=False
    )

    write_ambient_color: bpy.props.BoolProperty(
        name="Use Scene Ambient Color",
        description="Use the scene's world color for SCENEAMBIENTCOLOR (defaults if none)",
        default=False)

    scale: bpy.props.FloatProperty(
        name="Scale",
        description="Scale factor if needed",
        default=1.0, min=0.001)

    def execute(self, context):
        folder = os.path.dirname(self.filepath)
        base = os.path.basename(self.filepath)
        name = os.path.splitext(base)[0]

        armatures = [o for o in context.selected_objects if o.type == 'ARMATURE']
        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        
        exported_materials = set()

        if not armatures and not meshes:
            self.report({'ERROR'}, "Select at least one Armature or Mesh.")
            return {'CANCELLED'}

        # ---- SKELETON (XSF) ----
        if self.export_xsf:
            if armatures:
                for arm in armatures:
                    xsf_path = os.path.join(folder, f"{name}_{bpy.path.clean_name(arm.name)}.xsf")
                    export_xsf(arm, xsf_path, self.write_ambient_color, scale=self.scale)
            else:
                if meshes:
                    xsf_path = os.path.join(folder, f"{name}_skeleton.xsf")
                    write_dummy_xsf(xsf_path, meshes[0].name)

        # ---- SKELETAL ANIMATION (XAF) ----
        if self.export_xaf:
            for arm in armatures:
                if arm.animation_data and arm.animation_data.action:
                    xaf_path = os.path.join(folder, f"{name}_{bpy.path.clean_name(arm.animation_data.action.name)}.xaf")
                    export_xaf(arm, xaf_path, scale=self.scale, keyframe_all=self.keyframe_all)

        # ---- MESHES & MATERIALS (XMF/XRF) ----
        for m_obj in meshes:
            if self.export_xmf:
                xmf_path = os.path.join(folder, f"{name}_{bpy.path.clean_name(m_obj.name)}.xmf")
                export_xmf(m_obj, xmf_path, scale=self.scale, 
                           export_xrf_flag=self.export_xrf, prefix=name, 
                           copy_textures=self.copy_textures, exported_mats=exported_materials,
                           compress=self.compress_xmf)


        # ---- MORPH ANIMATION (XPF) ----
        if self.export_xpf:
            morph_meshes = [m for m in meshes if m.data.shape_keys and 
                            m.data.shape_keys.animation_data and 
                            m.data.shape_keys.animation_data.action]
            
            if morph_meshes:
                if self.merge_xpf:
                    action_name = morph_meshes[0].data.shape_keys.animation_data.action.name
                    xpf_path = os.path.join(folder, f"{name}_{bpy.path.clean_name(action_name)}.xpf")
                    export_xpf(morph_meshes, xpf_path)
                else:
                    for m in morph_meshes:
                        action_name = m.data.shape_keys.animation_data.action.name
                        xpf_path = os.path.join(folder, f"{name}_{bpy.path.clean_name(action_name)}.xpf")
                        export_xpf([m], xpf_path)

        self.report({'INFO'}, "IMVU Cal3D Export Complete")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout

        # Dropdown 1: Cal3D File Options
        box1 = layout.box()
        box1.label(text="Cal3D File Options", icon='FILE_CACHE')
        col = box1.column(align=True)
        col.prop(self, "export_xsf")
        col.prop(self, "export_xmf")
        if self.export_xmf:
            row = col.row()
            row.separator()
            row.prop(self, "compress_xmf")
        col.prop(self, "export_xrf")
        col.prop(self, "export_xaf")
        col.prop(self, "export_xpf")

        # Dropdown 2: Other Options
        box2 = layout.box()
        box2.label(text="Other Options", icon='SETTINGS')
        col = box2.column(align=True)
        col.prop(self, "copy_textures")
        col.prop(self, "keyframe_all")
        col.prop(self, "merge_xpf")
        col.prop(self, "write_ambient_color")
        col.separator()
        col.prop(self, "scale")

def menu_func_export(self, context):
    self.layout.operator(EXPORT_OT_imvu_all.bl_idname, text="IMVU Cal3D Export")

def register():
    bpy.utils.register_class(EXPORT_OT_imvu_all)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.utils.unregister_class(EXPORT_OT_imvu_all)

if __name__ == "__main__":
    register()
